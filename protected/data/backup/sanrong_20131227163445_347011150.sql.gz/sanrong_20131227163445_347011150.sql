/* This file is created by MySQLReback 2013-12-27 16:34:45 */
 /* 创建数据库 `sanrong` */
 DROP DATABASE IF EXISTS `sanrong`;/* MySQLReback Separation */ CREATE DATABASE `sanrong` /*!40100 DEFAULT CHARACTER SET utf8 */;/* MySQLReback Separation */
 /* 创建表结构 `admin`  */
 DROP TABLE IF EXISTS `admin`;/* MySQLReback Separation */ CREATE TABLE `admin` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `last_login` int(32) NOT NULL DEFAULT '0',
  `last_ip` varchar(32) NOT NULL DEFAULT '',
  `logins` int(32) NOT NULL DEFAULT '0',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `admin` */
 INSERT INTO `admin` VALUES ('1','admin','c0e024d9200b5705bc4804722636378a','1388117659','127.0.0.1','62','0');/* MySQLReback Separation */
 /* 创建表结构 `advert`  */
 DROP TABLE IF EXISTS `advert`;/* MySQLReback Separation */ CREATE TABLE `advert` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '广告名称',
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '广告类型',
  `image` varchar(128) NOT NULL DEFAULT '' COMMENT '广告图片',
  `content` text NOT NULL COMMENT '广告内容或者js代码',
  `position` tinyint(2) NOT NULL DEFAULT '0' COMMENT '广告位置',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '广告状态',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `advert` */
 INSERT INTO `advert` VALUES ('1','adsfads','0','','12312ddsdf','0','1','1388118921'),('3','adfasdf','1','','','0','1','1388119143'),('4','asdfasdf','2','','asdfadsf','0','0','1388119151');/* MySQLReback Separation */
 /* 创建表结构 `friendlink`  */
 DROP TABLE IF EXISTS `friendlink`;/* MySQLReback Separation */ CREATE TABLE `friendlink` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '' COMMENT '名称',
  `url` varchar(128) NOT NULL DEFAULT '' COMMENT '链接',
  `is_target` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否新窗口打开 ',
  `sort` int(32) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `friendlink` */
 INSERT INTO `friendlink` VALUES ('1','3123a','23213','0','12','1','1388120597');/* MySQLReback Separation */
 /* 创建表结构 `groupon_area`  */
 DROP TABLE IF EXISTS `groupon_area`;/* MySQLReback Separation */ CREATE TABLE `groupon_area` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '区域名',
  `pid` tinyint(2) NOT NULL DEFAULT '0' COMMENT '区域等级',
  `first_letter` varchar(4) NOT NULL DEFAULT '' COMMENT '首字母',
  `goods` text COMMENT '商品集合，用,号隔开',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `groupon_area` */
 INSERT INTO `groupon_area` VALUES ('10','海口市','0','','','1387970954'),('11','深圳市','0','','','1387970976'),('12','福田区','11','','3,3,3','1387970985'),('13','罗湖区','11','','3,2,3,3','1387970995'),('14','龙华区','11','','3,2,3,3','1387971006'),('15','宝安区','11','','3,3,3','1387971014'),('16','光明新区','11','','','1387971024'),('17','龙岗区','11','','2','1387971037'),('18','盐田区','11','','2','1387971048');/* MySQLReback Separation */
 /* 创建表结构 `groupon_category`  */
 DROP TABLE IF EXISTS `groupon_category`;/* MySQLReback Separation */ CREATE TABLE `groupon_category` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '分类名称',
  `pid` tinyint(2) NOT NULL DEFAULT '0' COMMENT '等级ID',
  `is_hot` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否热门分类',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `groupon_category` */
 INSERT INTO `groupon_category` VALUES ('9','美食','0','0','1387975047'),('10','电影','0','0','1387975059'),('11','休闲娱乐','0','0','1387975067'),('12','酒店','0','1','1387975077'),('13','旅游','0','1','1387975084'),('14','火锅','9','1','1387976031'),('15','自助餐','9','1','1387976043'),('16','蛋糕','9','0','1387976057'),('17','日本料理','9','1','1387976067'),('18','KTV','11','1','1387976105'),('19','温泉','11','0','1387976116'),('20','SPA','11','1','1387976128'),('21','经济型酒店','12','1','1387976154'),('22','豪华型酒店','12','0','1387976164'),('23','度假酒店','12','0','1387976177'),('24','公寓酒店','12','0','1387976184');/* MySQLReback Separation */
 /* 创建表结构 `groupon_comment`  */
 DROP TABLE IF EXISTS `groupon_comment`;/* MySQLReback Separation */ CREATE TABLE `groupon_comment` (
  `id` int(32) NOT NULL DEFAULT '0',
  `goods_id` int(32) NOT NULL DEFAULT '0' COMMENT '商品id',
  `score` tinyint(2) NOT NULL DEFAULT '0' COMMENT '评价分数',
  `content` varchar(256) NOT NULL DEFAULT '' COMMENT '评论内容',
  `user_id` int(32) NOT NULL DEFAULT '0' COMMENT '评论人的id',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `groupon_goods`  */
 DROP TABLE IF EXISTS `groupon_goods`;/* MySQLReback Separation */ CREATE TABLE `groupon_goods` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `summary` varchar(256) NOT NULL DEFAULT '' COMMENT '摘要',
  `seller_id` int(32) NOT NULL DEFAULT '0' COMMENT '商家id',
  `area` text NOT NULL COMMENT '区域id集合',
  `cate_id` int(32) NOT NULL DEFAULT '0' COMMENT '类别id',
  `subject_id` int(32) NOT NULL DEFAULT '0' COMMENT '专题ID',
  `s_time` int(32) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `e_time` int(32) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `is_recommend` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否推荐',
  `is_top` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否置顶',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `image` varchar(128) NOT NULL DEFAULT '' COMMENT '缩略图',
  `m_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '市场价',
  `g_price` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '团购价',
  `views` int(32) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `content` text COMMENT '团购内容',
  `tip` varchar(256) NOT NULL DEFAULT '' COMMENT '消费提示',
  `feature` varchar(256) NOT NULL DEFAULT '' COMMENT '特色亮点',
  `admin_id` int(32) NOT NULL DEFAULT '0' COMMENT '团购添加者（后台管理员）',
  `relation_seller_id` varchar(128) NOT NULL DEFAULT '' COMMENT '推荐关联商家id',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `groupon_goods` */
 INSERT INTO `groupon_goods` VALUES ('1','fsdf','sdfs','4','10','14','0','12','1','1','1','2','/upload/1312/2523/36/52bafb7e59c6b.jpg','213.00','2.00','123','<p>sdfsfas</p>','123','123','0','','1387985018'),('2','fs','fsadfd','4','13,14,17,18','9','1','-28800','-28800','0','0','1','','0.00','0.00','0','','','','1','','1387985192'),('3','asdf','sdfsad','4','12,13,14,15','9','1','1387209600','1387900800','1','1','1','','2.00','3.00','0','','','','1','','1387985240');/* MySQLReback Separation */
 /* 创建表结构 `groupon_seller`  */
 DROP TABLE IF EXISTS `groupon_seller`;/* MySQLReback Separation */ CREATE TABLE `groupon_seller` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '商家名称',
  `contact` varchar(128) NOT NULL DEFAULT '' COMMENT '联系方式',
  `address` varchar(128) NOT NULL DEFAULT '' COMMENT '地址',
  `coord` varchar(128) NOT NULL DEFAULT '' COMMENT '坐标',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `groupon_seller` */
 INSERT INTO `groupon_seller` VALUES ('2','商家1','123123','123123','123213','1387974847'),('3','商家2','13123','12312','12312,123213','1387974991'),('4','商家3','fadsfsd','fsdafsdaf','13123,1312','1387975003');/* MySQLReback Separation */
 /* 创建表结构 `groupon_subject`  */
 DROP TABLE IF EXISTS `groupon_subject`;/* MySQLReback Separation */ CREATE TABLE `groupon_subject` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '专题名称',
  `is_hot` tinyint(2) NOT NULL DEFAULT '0',
  `pid` tinyint(2) NOT NULL DEFAULT '0',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `groupon_subject` */
 INSERT INTO `groupon_subject` VALUES ('1','sdaf','1','0','1388065292');/* MySQLReback Separation */
 /* 创建表结构 `news`  */
 DROP TABLE IF EXISTS `news`;/* MySQLReback Separation */ CREATE TABLE `news` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL DEFAULT '' COMMENT '标题',
  `cate_id` int(32) NOT NULL DEFAULT '0' COMMENT '类别id',
  `views` int(32) NOT NULL DEFAULT '0' COMMENT '浏览量',
  `content` text COMMENT '内容',
  `keyword` varchar(128) NOT NULL DEFAULT '' COMMENT '关键词',
  `description` text NOT NULL COMMENT '描述',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `news` */
 INSERT INTO `news` VALUES ('1','asdf','1','12','<p>adsf塔顶</p>','sdafs','1231','1388063496');/* MySQLReback Separation */
 /* 创建表结构 `news_category`  */
 DROP TABLE IF EXISTS `news_category`;/* MySQLReback Separation */ CREATE TABLE `news_category` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '新闻类名称',
  `pid` tinyint(2) NOT NULL DEFAULT '0',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `news_category` */
 INSERT INTO `news_category` VALUES ('1','分类1','0','1388061942'),('2','分类2','0','1388061949'),('3','分类3','0','1388061954');/* MySQLReback Separation */
 /* 创建表结构 `setting`  */
 DROP TABLE IF EXISTS `setting`;/* MySQLReback Separation */ CREATE TABLE `setting` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `key` varchar(32) NOT NULL DEFAULT '' COMMENT '项',
  `value` text NOT NULL COMMENT '值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `upload`  */
 DROP TABLE IF EXISTS `upload`;/* MySQLReback Separation */ CREATE TABLE `upload` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_type` int(10) NOT NULL DEFAULT '0' COMMENT '用户类型，管理平台0',
  `user_id` int(10) NOT NULL COMMENT '用户ID',
  `item_type` int(10) NOT NULL DEFAULT '0',
  `item_id` int(10) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `file` varchar(50) NOT NULL,
  `size` int(10) NOT NULL DEFAULT '0',
  `ext` varchar(5) NOT NULL,
  `uniqid` varchar(15) NOT NULL,
  `created` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据 `upload` */
 INSERT INTO `upload` VALUES ('1','2','7','1','3','20130905_070154.jpg','/upload/1309/05/52285161613de.jpg','16626','jpg','','1378373985'),('2','2','7','1','4','QQ截图20130905185346.jpg','/upload/1309/05/522862c0e982f.jpg','11054','jpg','','1378378432'),('3','2','7','1','5','QQ截图20130905185422.jpg','/upload/1309/05/522862f4dd035.jpg','26871','jpg','','1378378484'),('4','2','7','1','6','QQ截图20130905185507.jpg','/upload/1309/05/5228631ed7357.jpg','26687','jpg','','1378378526'),('5','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e86bab8512.jpg','64462','jpg','','1378780858'),('6','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e8b6133f6c.jpg','64462','jpg','','1378782049'),('7','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e8be7c9fb1.jpg','64462','jpg','','1378782183'),('8','1','7','0','0','rBEhVVIIS9IIAAAAAADpNzokZ80AAB_hwAwqgsAAOlP485.jpg','/upload/1309/10/522e8c3631e6b.jpg','59705','jpg','','1378782262'),('9','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e8c807280e.jpg','55833','jpg','','1378782336'),('10','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e8ca0f2f0a.jpg','55833','jpg','','1378782368'),('11','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e8da8671f6.jpg','55833','jpg','','1378782632'),('12','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e90cd983a9.jpg','64462','jpg','','1378783437'),('13','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e90cdace8a.jpg','55833','jpg','','1378783437'),('14','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e912080ed7.jpg','64462','jpg','','1378783520'),('15','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e9120992ce.jpg','55833','jpg','','1378783520'),('16','1','7','0','0','rBEhUlIIQAUIAAAAAAD7zAbJMhoAAB9RgKCFlAAAPvk241.jpg','/upload/1309/10/522e9151ebb8a.jpg','64462','jpg','','1378783569'),('17','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/10/522e9191b9bee.jpg','55833','jpg','','1378783633'),('18','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/1003/522e91da8b490.jpg','55833','jpg','','1378783706'),('19','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/1003/522e9253dc041.jpg','55833','jpg','','1378783827'),('20','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/1003/31522e92760c282.jpg','55833','jpg','','1378783862'),('21','1','7','0','0','rBEhVVIIrUIIAAAAAADaF_vIga0AACAxwMJXhUAANov013.jpg','/upload/1309/1003/31/522e92963cc17.jpg','55833','jpg','','1378783894'),('22','1','7','2','1','Chrysanthemum.jpg','/upload/1310/0807/52/5253b9c6ed988.jpg','879394','jpg','','1381218758'),('23','1','7','0','0','Tulips.jpg','/upload/1310/0808/06/5253bd11485d7.jpg','620888','jpg','','1381219601'),('24','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/07/5253bd4b8caed.jpg','879394','jpg','','1381219659'),('25','1','7','2','2','Chrysanthemum.jpg','/upload/1310/0808/08/5253bd8947352.jpg','879394','jpg','','1381219721'),('26','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/10/5253bddebc547.jpg','879394','jpg','','1381219806'),('27','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/10/5253bdedb6936.jpg','879394','jpg','','1381219821'),('28','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/11/5253be1b43b33.jpg','879394','jpg','','1381219867'),('29','1','7','2','3','Desert.jpg','/upload/1310/0808/11/5253be3243185.jpg','845941','jpg','','1381219890'),('30','1','7','2','4','Desert.jpg','/upload/1310/0808/14/5253beeaa184a.jpg','845941','jpg','','1381220074'),('31','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/16/5253bf5f33a7f.jpg','879394','jpg','','1381220191'),('32','1','7','0','0','Chrysanthemum.jpg','/upload/1310/0808/17/5253bfa9d119a.jpg','879394','jpg','','1381220265'),('33','1','7','2','5','Desert.jpg','/upload/1310/0808/19/5253c02ec864c.jpg','845941','jpg','','1381220398'),('34','1','7','2','6','Desert.jpg','/upload/1310/0808/24/5253c133b68fa.jpg','845941','jpg','','1381220659'),('35','1','7','2','7','Hydrangeas.jpg','/upload/1310/0808/36/5253c42bd702d.jpg','595284','jpg','','1381221419'),('36','0','0','0','0','Chrysanthemum.jpg','/upload/1312/2523/36/52bafb7e59c6b.jpg','879394','jpg','','1387985790'),('37','0','0','0','0','QQ截图20131226153449.png','/upload/1312/2712/39/52bd0467158d0.png','5508','png','','1388119143'),('38','0','0','0','0','QQ截图20131226153449.png','/upload/1312/2712/47/52bd065bba243.png','5508','png','','1388119643');/* MySQLReback Separation */
 /* 创建表结构 `user`  */
 DROP TABLE IF EXISTS `user`;/* MySQLReback Separation */ CREATE TABLE `user` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `email` varchar(64) NOT NULL DEFAULT '' COMMENT '邮箱',
  `last_login` int(32) NOT NULL DEFAULT '0',
  `last_ip` varchar(32) NOT NULL DEFAULT '',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '0为个人，1为企业',
  `logins` int(32) NOT NULL DEFAULT '0',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `user_education`  */
 DROP TABLE IF EXISTS `user_education`;/* MySQLReback Separation */ CREATE TABLE `user_education` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `resume_id` int(32) NOT NULL DEFAULT '0' COMMENT '简历id',
  `from_time` int(32) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `to_time` int(32) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `school` varchar(128) NOT NULL DEFAULT '' COMMENT '学校名称',
  `major` varchar(128) NOT NULL DEFAULT '' COMMENT '专业名称',
  `degree` tinyint(2) NOT NULL DEFAULT '0' COMMENT '学位',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `user_experience`  */
 DROP TABLE IF EXISTS `user_experience`;/* MySQLReback Separation */ CREATE TABLE `user_experience` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `resume_id` int(32) NOT NULL DEFAULT '0' COMMENT '简历id',
  `company_name` varchar(128) NOT NULL DEFAULT '' COMMENT '企业名称',
  `company_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '企业性质',
  `company_size` tinyint(2) NOT NULL DEFAULT '0' COMMENT '企业规模',
  `department` varchar(128) NOT NULL DEFAULT '' COMMENT '所在部门',
  `position` varchar(128) NOT NULL DEFAULT '' COMMENT '职位名称',
  `from_time` int(32) NOT NULL DEFAULT '0' COMMENT '开始时间',
  `to_time` int(32) NOT NULL DEFAULT '0' COMMENT '结束时间',
  `charge_name` varchar(64) NOT NULL DEFAULT '' COMMENT '主管名字',
  `charge_contact` varchar(64) NOT NULL DEFAULT '' COMMENT '主管联系方式',
  `charge_card` varchar(128) NOT NULL DEFAULT '' COMMENT '主管名称扫描件路径',
  `description` text NOT NULL COMMENT '工作描述',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `user_info`  */
 DROP TABLE IF EXISTS `user_info`;/* MySQLReback Separation */ CREATE TABLE `user_info` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(32) NOT NULL DEFAULT '0' COMMENT '会员id',
  `gender` tinyint(2) NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` int(32) NOT NULL DEFAULT '0' COMMENT '出生日期',
  `experience` tinyint(2) NOT NULL DEFAULT '0' COMMENT '工作经验',
  `marry_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '婚姻状况',
  `lid_type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '证件类型',
  `lid_number` varchar(32) NOT NULL DEFAULT '0' COMMENT '证件号码',
  `political_status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '政治面貌',
  `province_id` int(32) NOT NULL DEFAULT '0' COMMENT '省',
  `city_id` int(32) NOT NULL DEFAULT '0' COMMENT '市',
  `district_id` int(32) NOT NULL DEFAULT '0' COMMENT '区',
  `address` varchar(128) NOT NULL DEFAULT '' COMMENT '地址',
  `tel` varchar(16) NOT NULL DEFAULT '' COMMENT '电话',
  `mobile` varchar(16) NOT NULL DEFAULT '' COMMENT '手机',
  `created` int(32) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构 `user_resume`  */
 DROP TABLE IF EXISTS `user_resume`;/* MySQLReback Separation */ CREATE TABLE `user_resume` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `user_id` int(32) NOT NULL DEFAULT '0' COMMENT '会员ID',
  `user_info_id` int(32) NOT NULL DEFAULT '0' COMMENT '会员信息id',
  `user_sign` text NOT NULL COMMENT '个人签名',
  `user_introduce` text NOT NULL COMMENT '个人介绍',
  `user_education_id` int(32) NOT NULL DEFAULT '0' COMMENT '个人教育经历id',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '简历状态',
  `created` int(32) NOT NULL DEFAULT '0' COMMENT '创建时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;/* MySQLReback Separation */